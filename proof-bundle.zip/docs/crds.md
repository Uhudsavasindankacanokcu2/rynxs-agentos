# CRDs

## Universe
Global rules: sleep/backup, luck, physics jitter, identity bleed, travel policy, bucket config.

## Agent
Provider config + tool allowlist + workspace + network allowlist + persona/cognition params.

## Session
Optional ephemeral sessions for risky tools / travel.
